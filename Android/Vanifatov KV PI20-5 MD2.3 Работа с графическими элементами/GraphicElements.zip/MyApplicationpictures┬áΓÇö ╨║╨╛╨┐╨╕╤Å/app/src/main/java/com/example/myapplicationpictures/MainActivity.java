package com.example.myapplicationpictures;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClick(View v) {
        Intent intent;

        switch(v.getId()) {
            case R.id.butTime:
                intent = new Intent(MainActivity.this, dayActivity2.class);
                startActivity(intent);
                break;
            case R.id.butDate:
                intent = new Intent(MainActivity.this, studyActivity2.class);
                startActivity(intent);
                break;
        }
    }

}