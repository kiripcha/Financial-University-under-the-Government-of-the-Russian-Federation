package com.example.myapplicationpictures;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class dayActivity2 extends AppCompatActivity {

    Button mainButton;
    EditText mainEditText;
    ListView mainListView;
    ArrayAdapter mArrayAdapter;
    ArrayList mNameList = new ArrayList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_day2);

        mainListView = findViewById(R.id.main_listview_d);

        mArrayAdapter = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                mNameList);
        mainListView.setAdapter(mArrayAdapter);


        mainEditText = (EditText) findViewById(R.id.main_edittext_d);

        mainButton = findViewById(R.id.button_d);

        button();


    }
    void button () {
        mainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mNameList.add(mainEditText.getText().toString());
                mArrayAdapter.notifyDataSetChanged();
            }
        });
    }
}