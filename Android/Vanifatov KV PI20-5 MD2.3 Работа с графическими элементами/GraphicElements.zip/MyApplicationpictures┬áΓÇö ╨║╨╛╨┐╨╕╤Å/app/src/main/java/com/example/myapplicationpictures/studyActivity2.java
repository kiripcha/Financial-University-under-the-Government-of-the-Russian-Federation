package com.example.myapplicationpictures;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class studyActivity2 extends AppCompatActivity {

    Button mainButton1;
    EditText mainEditText1;
    ListView mainListView1;
    ArrayAdapter mArrayAdapter1;
    ArrayList mNameList12 = new ArrayList();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_study2);

        mainListView1 = findViewById(R.id.main_listview_u);
        mArrayAdapter1 = new ArrayAdapter(this,
                android.R.layout.simple_list_item_1,
                mNameList12);
        mainListView1.setAdapter(mArrayAdapter1);


        mainEditText1 = (EditText) findViewById(R.id.main_edittext_u);

        mainButton1 = findViewById(R.id.button_u);

        button();


    }
    void button () {
        mainButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mNameList12.add(mainEditText1.getText().toString());
                mArrayAdapter1.notifyDataSetChanged();
            }
        });
    }
}